import TariffHistory from "../models/tariff-history.model.js";

export default TariffHistory;
