export class IAuthService {
    async getUserProfile(userId) {throw new Error('Method not implemented');}
    async validatePermissions(userId, requiredPermissions) {throw new Error('Method not implemented');}
}