export class IChatService {
    async startChat(participants, rideId) { throw new Error('Method not implemented'); }
    async postMessage(chatId, message) { throw new Error('Method not implemented'); }
    async getChatHistory(chatId, requester) { throw new Error('Method not implemented'); }
    async archiveChat(chatId, requester) { throw new Error('Method not implemented'); }
}