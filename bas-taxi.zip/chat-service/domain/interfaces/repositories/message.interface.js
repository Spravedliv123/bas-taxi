export class IMessageRepository {
    async create(message) { throw new Error('Not implemented'); }
    async findByRide(rideId) { throw new Error('Not implemented'); }
    async findByUser(userId) { throw new Error('Not implemented'); }
}