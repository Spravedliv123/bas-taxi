export class IEventPublisher {
    async publish(eventType, payload) {
        throw new Error('Not implemented');
    }
}